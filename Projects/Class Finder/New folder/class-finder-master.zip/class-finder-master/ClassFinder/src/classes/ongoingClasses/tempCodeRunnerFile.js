getCurrentDay();
getCurrentTime();